print ("Time of Travel")
destination = input('enter destination') 
distance = float(input('enter distance'))
speed = float(input('enter speed'))
time = distance/speed
print(time)