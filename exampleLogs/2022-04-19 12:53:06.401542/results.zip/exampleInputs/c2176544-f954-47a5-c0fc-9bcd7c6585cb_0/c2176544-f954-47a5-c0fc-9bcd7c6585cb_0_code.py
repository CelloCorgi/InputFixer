no_of_element = int(input())
A = []
for i in range(no_of_element):
    ele_to_add = int(input())
    A.append(ele_to_add)

A