n = int(input("enter a number"))
for i in range(n):
    
    import random
    print(random.randrange(1,n))
    
    