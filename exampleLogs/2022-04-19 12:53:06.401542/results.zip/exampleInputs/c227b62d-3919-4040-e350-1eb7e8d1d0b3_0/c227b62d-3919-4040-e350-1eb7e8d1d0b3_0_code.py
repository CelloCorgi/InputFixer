temp = input("celsius or fahrenheit")
if temp == str("Celsius"):
    c=(int(input("number")))
    convert = (9 * c / 5 + 32)
    print("number is " + str(celsius))