y = int(input())
x = int(input())
print=x^3+y^2