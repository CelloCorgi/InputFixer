x=int(input(" "))
y=int(input(" "))
z=x/y
print("the division of two number is:",z)