num1 = int(input(" Please enter the first number: "))
num2 = int(input(" Please enter the second number: "))
num3 = (int(num1) + int(num2))
x=num3
if x > 100:
    print("They add up to a big number")
elif x <= 100:
    print("They add up to: " + x)  
