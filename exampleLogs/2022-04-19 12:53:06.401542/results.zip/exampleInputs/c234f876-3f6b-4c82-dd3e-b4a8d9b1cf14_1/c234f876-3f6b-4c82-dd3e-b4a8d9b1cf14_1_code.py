n = input()
b=[]
for i in range(len(n)):
    b[i] = int(input())
    