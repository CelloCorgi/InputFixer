def convertbinary():
    binarystring = input(str("Enter a binary string value. Example, 11111111."))
    x = int(binarystring, 2)
    return x 

convertbinary()
